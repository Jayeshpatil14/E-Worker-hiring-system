package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Services.UsersServices;
import com.example.demo.Services.WorkerServices;
import com.example.demo.entities.UserRegister;
import com.example.demo.entities.Users;
import com.example.demo.entities.Worker;

@CrossOrigin(origins ="http://localhost:3000")
@RestController
@RequestMapping("/worker")
public class WorkerController {

	@Autowired
	private WorkerServices wservices;
	
	@Autowired
	UsersServices uservices;

	@PostMapping("/saveworker")
	public void saveclient(@RequestBody UserRegister ur) {
		Users u = new Users(ur.getFname(), ur.getLname(), ur.getEmail(), ur.getPassword(), ur.getContact_no(),
				ur.getGender(), ur.getUser_type(), ur.getAddress());

		uservices.save(u);

		Worker w = new Worker(ur.getWorker_type(), u);
		
		wservices.saveWorker(w);
	}
}
