package com.example.demo.entities;

public class UserRegister {	
	private String fname;
	private String lname;
	private String contact_no;
	private String email;
	private String address;
	private String gender;
	private String user_type;
	private String client_type;
	private String worker_type;
	private String password;
	
	public UserRegister() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRegister(String fname, String lname, String contact_no, String email, String address, String gender,
			String user_type, String client_type, String worker_type, String password) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.contact_no = contact_no;
		this.email = email;
		this.address = address;
		this.gender = gender;
		this.user_type = user_type;
		this.client_type = client_type;
		this.worker_type = worker_type;
		this.password = password;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public String getClient_type() {
		return client_type;
	}

	public void setClient_type(String client_type) {
		this.client_type = client_type;
	}

	public String getWorker_type() {
		return worker_type;
	}

	public void setWorker_type(String worker_type) {
		this.worker_type = worker_type;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "UserRegister [fname=" + fname + ", lname=" + lname + ", contact_no=" + contact_no + ", email=" + email
				+ ", address=" + address + ", gender=" + gender + ", user_type=" + user_type + ", client_type="
				+ client_type + ", worker_type=" + worker_type + ", password=" + password + "]";
	}
	
	
	
}
