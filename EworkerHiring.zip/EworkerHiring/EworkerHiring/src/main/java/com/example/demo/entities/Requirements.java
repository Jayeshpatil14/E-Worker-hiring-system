package com.example.demo.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="Requirements")
public class Requirements {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int requirement_id;
	@Column
	private String req_date;
	@Column
	private int work_days;
	@Column
	private int no_of_workers;
	@Column
	private String location;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.MERGE)
	@JoinColumn(name="client_id")
	private Client client_id;

	public Requirements() {
		super();
	}

	public Requirements(int requirement_id, String req_date, int work_days, int no_of_workers, String location,
			Client client_id) {
		super();
		this.requirement_id = requirement_id;
		this.req_date = req_date;
		this.work_days = work_days;
		this.no_of_workers = no_of_workers;
		this.location = location;
		this.client_id = client_id;
	}

	public int getRequirement_id() {
		return requirement_id;
	}

	public void setRequirement_id(int requirement_id) {
		this.requirement_id = requirement_id;
	}

	public String getReq_date() {
		return req_date;
	}

	public void setReq_date(String req_date) {
		this.req_date = req_date;
	}

	public int getWork_days() {
		return work_days;
	}

	public void setWork_days(int work_days) {
		this.work_days = work_days;
	}

	public int getNo_of_workers() {
		return no_of_workers;
	}

	public void setNo_of_workers(int no_of_workers) {
		this.no_of_workers = no_of_workers;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Client getClient_id() {
		return client_id;
	}

	public void setClient_id(Client client_id) {
		this.client_id = client_id;
	}

	@Override
	public String toString() {
		return "Requirements [requirement_id=" + requirement_id + ", req_date=" + req_date + ", work_days=" + work_days
				+ ", no_of_workers=" + no_of_workers + ", location=" + location + ", client_id=" + client_id + "]";
	}
	
}