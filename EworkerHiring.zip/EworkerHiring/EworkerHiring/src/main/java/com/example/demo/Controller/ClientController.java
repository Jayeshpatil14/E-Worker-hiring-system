package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Services.ClientServices;
import com.example.demo.Services.UsersServices;
import com.example.demo.Services.WorkerServices;
import com.example.demo.entities.Client;
import com.example.demo.entities.UserRegister;
import com.example.demo.entities.Users;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/client")
public class ClientController {

	@Autowired
	ClientServices cservices;
	@Autowired
	UsersServices uservices;

	@PostMapping("/saveclient")
	public void saveclient(@RequestBody UserRegister ur) {
		Users u = new Users(ur.getFname(), ur.getLname(), ur.getEmail(), ur.getPassword(), ur.getContact_no(),
				ur.getGender(), ur.getUser_type(), ur.getAddress());

		uservices.save(u);

		Client c = new Client(ur.getClient_type(), u);
		
		cservices.saveclient(c);
	}
}
