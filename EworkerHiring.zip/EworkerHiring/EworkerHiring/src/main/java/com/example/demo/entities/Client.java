
package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "client")
public class Client {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int client_id;
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "user_id")
	private Users user_id;
	@Column
	private String client_type;
	@Column
	private int req_detail_id;
	@Column
	private int req_id;

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Client(int client_id) {
		this.client_id = client_id;
	}

	public Client(String client_type, Users user_id) {
		this.user_id = user_id;
		this.client_type = client_type;
	}

	public Client(String client_type) {
		super();
		this.client_type = client_type;
	}

	public Client(int client_id, Users user_id, String client_type, int req_detail_id, int req_id) {
		super();
		this.client_id = client_id;
		this.user_id = user_id;
		this.client_type = client_type;
		this.req_detail_id = req_detail_id;
		this.req_id = req_id;
	}

	public int getClient_id() {
		return client_id;
	}

	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}

	public Users getUser_id() {
		return user_id;
	}

	public void setUser_id(Users user_id) {
		this.user_id = user_id;
	}

	public String getClient_type() {
		return client_type;
	}

	public void setClient_type(String client_type) {
		this.client_type = client_type;
	}

	public int getReq_detail_id() {
		return req_detail_id;
	}

	public void setReq_detail_id(int req_detail_id) {
		this.req_detail_id = req_detail_id;
	}

	public int getReq_id() {
		return req_id;
	}

	public void setReq_id(int req_id) {
		this.req_id = req_id;
	}

	@Override
	public String toString() {
		return "Client [client_id=" + client_id + ", user_id=" + user_id + ", client_type=" + client_type
				+ ", req_detail_id=" + req_detail_id + ", req_id=" + req_id + "]";
	}

}
