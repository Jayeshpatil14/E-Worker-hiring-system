/*package com.example.demo.entities;

import java.util.Date;

import javax.persistence.Entity;

@Entity
public class Payment {

	private int payment_id;
	private int transaction_id;
	private Date payment_date;
	private double payment_amount;
	private String payment_mode;
	private Requirement_Details req_det_id;
	private Worker worker_id;
	
}
*/