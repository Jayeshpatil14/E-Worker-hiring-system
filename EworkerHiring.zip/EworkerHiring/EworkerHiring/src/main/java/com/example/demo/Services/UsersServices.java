package com.example.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Users;
import com.example.demo.repositories.UserRepository;

@Service
public class UsersServices {

	@Autowired
	UserRepository urepos;
	
	public String checkLogin(String email,String password)
	{
		return urepos.checkLogin(email, password);
	}
	
	public Users save(Users u)
	{
		return urepos.save(u);//repository provide save()function
	}
}
