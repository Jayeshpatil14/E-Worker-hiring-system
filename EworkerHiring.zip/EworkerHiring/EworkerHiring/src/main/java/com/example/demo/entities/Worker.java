
package com.example.demo.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
//import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
//@PrimaryKeyJoinColumn(name="user_id")
@Table(name = "worker")
public class Worker {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int worker_id;
	
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "user_id")
	private Users user_id;
	
	@OneToMany(mappedBy = "worker_id")
	List<Requirement_Details>  reqdetails= new ArrayList<>();

	// int userid;

	@Column
	private String worker_type;

	@Column
	private int charges;

	/*
	 * @JsonBackReference
	 * 
	 * @ManyToOne
	 * 
	 * @JoinColumn(name="emp_id") private Employment_Details emp_id;
	 */

	public Worker() {

	}

	public Worker(Users user_id, String worker_type, int charges) {
		super();
		this.user_id = user_id;
		this.worker_type = worker_type;
		this.charges = charges;
		// this.emp_id = emp_id;
	}
	/*
	 * public Worker(int worker_id, Users user_id, String worker_type ) { super();
	 * this.worker_id = worker_id; this.user_id = user_id; this.worker_type =
	 * worker_type; //this.emp_details=emp_details; }
	 */

	public Worker(int worker_id, Users user_id, String worker_type, int charges) {
		super();
		this.worker_id = worker_id;
		this.user_id = user_id;
		this.worker_type = worker_type;
		this.charges = charges;
	}

	public Worker(String labour_type) {
		super();
		this.worker_type = worker_type;
	}

	public Worker(String worker_type, Users user_id) {
		this.worker_type = worker_type;
		this.user_id = user_id;
	}

	/*
	 * public Worker(String worker_type, int userid) { this.worker_type=worker_type;
	 * this.userid=userid; }
	 */

	public int getWorker_id() {
		return worker_id;
	}

	public void setWorker_id(int worker_id) {
		this.worker_id = worker_id;
	}

	public Users getUser_id() {
		return user_id;
	}

	public void setUser_id(Users user_id) {
		this.user_id = user_id;
	}

	/*
	 * public List<Employment_Details> getEmp_details() { return emp_details; }
	 * 
	 * 
	 * public void setEmp_details(List<Employment_Details> emp_details) {
	 * this.emp_details = emp_details; }
	 */

	public String getWorker_type() {
		return worker_type;
	}

	public void setWorker_type(String worker_type) {
		this.worker_type = worker_type;
	}

	public int getCharges() {
		return charges;
	}

	public void setCharges(int charges) {
		this.charges = charges;
	}

	@Override
	public String toString() {
		return "Worker [worker_id=" + worker_id + ", user_id=" + user_id + ", worker_type=" + worker_type + ", Charges="
				+ charges + "]";
	}

}
