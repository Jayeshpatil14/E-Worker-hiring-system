package com.example.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.Worker;
import com.example.demo.repositories.WorkerRepository;

@Service
public class WorkerServices {

	@Autowired
	private WorkerRepository wrepos;
	
	public Worker saveWorker(Worker w)
	{
		return wrepos.save(w);//repository provide save()function
	}
}
