
 package com.example.demo.entities;
 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Requirement_Details")
public class Requirement_Details {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="req_details_id")
	private int requirement_details_id;
	@Column
	private String req_status;
	@Column
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private String req_date;
	@OneToOne
	@JoinColumn(name="requirement_id")
	private Requirements requirement_id;
	@ManyToOne
	@JoinColumn(name="worker_id")
	private Worker worker_id;
	
	public Requirement_Details() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Requirement_Details(int requirement_details_id, String req_status, String req_date,
			Requirements requirement_id, Worker worker_id) {
		super();
		this.requirement_details_id = requirement_details_id;
		this.req_status = req_status;
		this.req_date = req_date;
		this.requirement_id = requirement_id;
		this.worker_id = worker_id;
	}

	public int getRequirement_details_id() {
		return requirement_details_id;
	}

	public void setRequirement_details_id(int requirement_details_id) {
		this.requirement_details_id = requirement_details_id;
	}

	public String getReq_status() {
		return req_status;
	}

	public void setReq_status(String req_status) {
		this.req_status = req_status;
	}

	public String getReq_date() {
		return req_date;
	}

	public void setReq_date(String req_date) {
		this.req_date = req_date;
	}

	public Requirements getRequirement_id() {
		return requirement_id;
	}

	public void setRequirement_id(Requirements requirement_id) {
		this.requirement_id = requirement_id;
	}

	public Worker getWorker_id() {
		return worker_id;
	}

	public void setWorker_id(Worker worker_id) {
		this.worker_id = worker_id;
	}

	@Override
	public String toString() {
		return "Requirement_Details [requirement_details_id=" + requirement_details_id + ", req_status=" + req_status
				+ ", req_date=" + req_date + ", requirement_id=" + requirement_id + ", worker_id=" + worker_id + "]";
	}
	
}









