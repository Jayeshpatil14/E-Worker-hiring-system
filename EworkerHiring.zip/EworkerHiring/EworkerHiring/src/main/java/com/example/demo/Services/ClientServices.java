package com.example.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.Client;
import com.example.demo.repositories.ClientRepository;

@Service
public class ClientServices {

	@Autowired
	private ClientRepository crepos;
	
	public Client saveclient(Client c)
	{
		return crepos.save(c); //repository provide save()function
	}
}
